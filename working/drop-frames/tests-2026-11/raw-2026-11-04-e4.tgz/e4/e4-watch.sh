# e4-watch.sh <label> <max_s>: stop the recording at the first dropped frame, from the 1 Hz log (no per-second Core calls)
L=/run/apertar-media/take-$1.log; C="python3 -I $HOME/apertar-kb/working/tools/core.py"; n=0
while [ ! -f "$L" ]; do sleep 1; n=$((n+1)); [ $n -gt 120 ] && { echo "no $L after 120 s"; exit 1; }; done
echo "watching $L from $(date +%T)"; s=0
while [ $s -lt "$2" ]; do sleep 1; s=$((s+1))
  d=$(tail -n 1 "$L" 2>/dev/null | grep -oE "dropped=[0-9]+" | cut -d= -f2)
  if [ -n "$d" ] && [ "$d" -gt 0 ]; then echo "STOP ON DROP at watch ${s}s $(date +%T): dropped=$d"; $C record_stop | cut -c1-80; exit 0; fi
done; echo "no drop seen in $2 s ($(date +%T))"
