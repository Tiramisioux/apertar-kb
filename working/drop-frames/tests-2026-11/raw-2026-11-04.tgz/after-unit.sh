# after-unit.sh <unit> [takes...]: collect a unit from the Pi (never during a take), check, delete clips, analyse on the Mac
SP=/private/tmp/claude-502/-Users-patrikeriksson-Documents-Apertar/2c6054e0-d951-4dd7-a31b-b29b6d55e9cf/scratchpad/e3
U=$1; shift; TK=${*:-P1 P2}; mkdir -p $SP/$U
ssh apertar "bash /run/apertar-media/e3-collect.sh cut $U; python3 -I /run/apertar-media/loads.py $U"
F="e3-$U.out be-cfg-$U.json"; for t in $TK; do F="$F $U-$t.log take-e3-$U-$t.log take-e3-$U-$t.g1"; done
for f in $F; do scp -q apertar:/run/apertar-media/$f $SP/$U/ || echo "MISSING $f"; done
ok=1; for f in $F; do [ -s $SP/$U/$f ] || { [ "${f##*.}" = g1 ] || ok=0; }; done
if [ $ok = 1 ]; then ssh apertar "bash /run/apertar-media/e3-collect.sh delete $U && cd /run/apertar-media && rm -f $F .e3-cur.txt && ls"; else echo "NOT DELETED: a file is missing on the Mac"; fi
python3 -I -c "
import json; d=json.load(open('$SP/$U/be-cfg-$U.json')); b=d['config'][0]['global']['bayer_enables']; i=d['config'][1]['input_format']
print(f'be-cfg: bayer_enables {hex(b)} &0x140={hex(b&0x140)} input {i[\"width\"]}x{i[\"height\"]} stride {i[\"stride\"]}')"
grep -E '^(nvme at|memfree|fill|mode:|ui switches|start |recording clip|TAKE|NOT|STOPPED)|uptime_s|drive: ' $SP/$U/e3-$U.out | sed -E 's/ zone boost.*//; s/^label=.*(uptime_s=[0-9]+)/\1/' | cut -c1-230
cd $SP && python3 -I ~/Documents/Apertar/apertar-kb/working/tools/be_overlap.py $U --prefix e3 > $U/be_overlap.txt 2>&1; echo be_overlap rc=$?
sed -n '1,3p;/^1\./,/^$/p;/^4\./,/^$/p;/^6\./,$p' $U/be_overlap.txt
awk '/^2\./{f=1} /^3\./{f=0} f' $U/be_overlap.txt | grep -E 'u[0-9a-z]+-P|0-0.5' | head -6
