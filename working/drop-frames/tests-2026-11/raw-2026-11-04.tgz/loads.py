import re,sys
R='/run/apertar-media'; U=sys.argv[1]; out=open(f'{R}/e3-{U}.out').read()
offs=[int(x) for x in re.findall(r'^OFF\d+ (\d+)$', out, re.M)]
pos=0; loads=[]
with open(f'{R}/libcamera-e3.log','rb') as f:
    for line in f:
        if b'Using tuning file' in line: loads.append((pos, line.split(b'Using tuning file ')[1].strip().decode()))
        pos+=len(line)
for k,(a,b) in enumerate(zip(offs,offs[1:])):
    before=[l for l in loads if l[0]<a]; inside=[l for l in loads if a<=l[0]<b]
    print(f'P{k+1}: last load before window: {before[-1][1] if before else None}; inside: {[l[1] for l in inside]}')
