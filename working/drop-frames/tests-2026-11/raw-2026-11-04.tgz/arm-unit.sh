# arm-unit.sh <unit> <F|N> <prev-unit-for-trace>: arm via the helper, copy+rm the trace, switch the tuning, read back
SP=/private/tmp/claude-502/-Users-patrikeriksson-Documents-Apertar/2c6054e0-d951-4dd7-a31b-b29b6d55e9cf/scratchpad/e3
U=$1; ARM=$2; PREV=$3; mkdir -p $SP/$U $SP/$PREV
ssh apertar 'sudo -n /usr/local/libexec/apertar-b1-arm sync 2>&1 | grep -E "restarted|OK:|trace saved|!!!"' | tee $SP/$U/arm-$U.txt
T=$(grep -oE 'b1-trace-[0-9]+\.txt' $SP/$U/arm-$U.txt | head -1)
[ -n "$T" ] && scp -q apertar:/run/apertar-media/$T $SP/$PREV/${T%.txt}-$PREV.txt && ssh apertar "rm -v /run/apertar-media/$T"
case $ARM in F) P=/home/pi/Tuning-Files/imx585_clearHDR_notdn.json; W='custom, pisp';; N) P=; W='sensor default, pisp';; esac
ssh apertar "P='$P' W='$W' bash -s" <<'EOS' | tee $SP/$U/switch-$U.txt
R=/run/apertar-media
C="python3 -I $HOME/apertar-kb/working/tools/core.py"
ST(){ $C get_state | python3 -I -c "import sys,json; d=json.load(sys.stdin); print(d['state'], repr(d['tuning_file']))"; }
J(){ journalctl -b _PID=$(systemctl show -p MainPID --value apertar-core) --no-pager | grep -E 'ApertarCore tuning file|ignoring tuning|preview colour' | tail -3; }
M=$(systemctl show -p MainPID --value apertar-core); echo "MainPID $M $(date +%T)"
for i in $(seq 1 30); do L=$(J); [ -n "$L" ] && break; sleep 1; done; echo "$L"
echo "switch to '$P': $($C set_tuning_file path=$P | cut -c1-40)"
for i in $(seq 1 20); do J | tail -1 | grep -q "$W" && break; sleep 1; done; sleep 3
ST; J | tail -1
grep "Using tuning file" $R/libcamera-e3.log | tail -1 | cut -c1-200; stat -c '%y be-cfg' $R/be-cfg.json
python3 -I -c "import json; d=json.load(open('$R/be-cfg.json')); b=d['config'][0]['global']['bayer_enables']; print('dump', hex(b), hex(b&0x140))"
grep -c '"tdn"' /home/pi/Tuning-Files/imx585_clearHDR_notdn.json
echo web=$(ss -tnH state established "( sport = :8000 )" | wc -l) builds=$(ps -eo cmd | grep -cE "^[^ ]*(cc1plus|gmake|cmake) ") logins=$(who | wc -l) traces=$(ls $R/b1-trace-* 2>/dev/null | wc -l)
EOS
