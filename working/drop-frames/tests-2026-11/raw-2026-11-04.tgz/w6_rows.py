import re, os
D = os.path.dirname(os.path.abspath(__file__))
VM = ["pgsteal_kswapd","pgscan_direct","allocstall_movable","pageoutrun","kswapd_low_wmark_hit_quickly","pgmajfault","pswpin"]
VOID = "void (NVMe 40.85 C at the unit start)"

def parse(path):
    rows = []; prev = None
    for ln in open(path):
        if not ln.startswith("t="): continue
        t = float(re.match(r"t=([\d.]+)", ln).group(1))
        vm = {k:int(v) for k,v in re.findall(r"(\w+)=(\d+)", ln.split("| mem")[0].split(" vm ",1)[1])}
        nv = re.search(r"nvme writes=(\d+) ticks_ms=(\d+)", ln)
        ovf = int(re.search(r"csi2 ovf=(\d+)", ln).group(1))
        psi = int(re.search(r"psi some .*?total=(\d+)", ln).group(1))
        m = re.search(r"\| dropped=(\w+)", ln)
        d = int(m.group(1)) if m and m.group(1) != "None" else prev
        prev = d
        rows.append(dict(t=t, vm=vm, w=int(nv.group(1)), tk=int(nv.group(2)), ovf=ovf, psi=psi, dr=d))
    return rows

def peak(r, lim=None):
    best = None
    for i in range(1, len(r)):
        if lim is not None and i > lim: break
        dw = r[i]["w"]-r[i-1]["w"]
        if dw < 10: continue
        v = (r[i]["tk"]-r[i-1]["tk"])/dw
        if best is None or v > best[0]: best = (v, i, dw)
    return "%.2f ms (s %d, %d writes)" % best

def at(r, off):
    t0 = r[0]["t"]
    return min(r, key=lambda x: abs(x["t"]-(t0+off)))["dr"]

def sect(txt, takelabel):
    # returns console block of take
    m = re.search(r"===== %s\n(.*?)(?=\n===== |\nrestored\nOFF\d|\Z)" % takelabel, txt, re.S)
    return m.group(1)

def row(unit, p, test, arm, valid, out):
    r = parse(f"{D}/{unit}/take-e3-{unit}-{p}.log")
    txt = open(f"{D}/{unit}/e3-{unit}.out").read()
    # take block
    blocks = re.split(r"^===== ", txt, flags=re.M)
    blk = [b for b in blocks if b.startswith(p+"\n")][0]
    start = re.search(r"^start (\S+)", blk, re.M).group(1)
    mem = re.search(r"mem before: MemFree:(\d+)M", blk).group(1)
    enq = re.search(r"enqueued=(\d+)", blk).group(1)
    g1 = re.search(r"G1 \(CameraManager PMU, 60-120 s\):.*?cycles=(\w+)/s ipc=([\d.]+)", blk)
    g1s = "IPC %s, cycles %s/s" % (g1.group(2), g1.group(1))
    d0 = re.search(r"^drive: (\S+) used of \S+ \((\d+)%\) nvme=live (\d+) C", blk, re.M)
    d1 = re.search(r"drive after: (\S+) used of \S+ \((\d+)%\) (\d+) C", blk)
    drive = "%s (%s %%) %s C / %s (%s %%) %s C" % (d0.group(1), d0.group(2), d0.group(3), d1.group(1), d1.group(2), d1.group(3))
    a, b, c = at(r,60), at(r,120), at(r,180)
    last = r[-1]["dr"]
    base = 0 if r[0]["dr"] > r[1]["dr"] else r[0]["dr"]  # first line of a P2 log carries the previous take's stale counter
    lpm = "%d / %d / %d" % (a-base, b-a, c-b)
    if last-c: lpm += " (+%d after 180 s)" % (last-c)
    dl = " / ".join(str(r[-1]["vm"][k]-r[0]["vm"][k]) for k in VM)
    ovfs = [x["ovf"] for x in r]
    csi = "%d / %d" % (sum(ovfs), sum(1 for o in ovfs if o > 0))
    pk = "%s; within 0-180 s: %s" % (peak(r), peak(r, 180))
    psi = r[-1]["psi"]-r[0]["psi"]
    return "| e3-%s-%s | %s | %s | %s | %s | %s / %s | %s | %s | %s | %s | %d | %s | %s |" % (
        unit, p, test, arm, start, mem, lpm, last, enq, dl, g1s, pk, csi, psi, drive, valid) if False else \
        "| e3-%s-%s | %s | %s | %s | %s | %s | %s / %s | %s | %s | %s | %s | %s | %s |" % (
        unit, p, test, arm, start, mem, lpm, last, enq, dl, g1s, pk, csi, psi, drive) .replace(" | %s |" % "", " |") if False else \
        "| " + " | ".join([f"e3-{unit}-{p}", test, arm, start, mem, lpm, f"{last} / {enq}", dl, g1s, pk, csi, str(psi), drive, valid]) + " |"

L = []
L.append(row("warm","P1","evening 3 warm-up (unscored)","N (TDN on)","unscored",None))
for u,k,arm in [("u1",1,"N (TDN on)"),("u2",2,"F (TDN off)"),("u3",3,"F (TDN off)"),("u3r",3,"F (TDN off)"),("u4",4,"N (TDN on)")]:
    for p in ("P1","P2"):
        if u=="u3": test="evening 3 TDN block unit 3 %s (void unit)"%p; v=VOID
        elif u=="u3r": test="evening 3 TDN block unit 3 repeat (u3r) %s"%p; v="valid"
        else: test="evening 3 TDN block unit %d %s"%(k,p); v="valid"
        L.append(row(u,p,test,arm,v,None))
for p in ("P1","P2"):
    L.append(row("u27",p,"evening 3 27-fps unit %s"%p,"F (TDN off), 27 fps","valid",None))
L.append(row("s26","P1","evening 3 sweep 26 fps","F (TDN off), 26 fps","valid",None))
L.append(row("s28","P1","evening 3 sweep 28 fps","F (TDN off), 28 fps","valid",None))
print("### Evening 3 (2026-11-04)\n")
print("| take id | test | arm or cell | start (time) | start MemFree (MB) | lost per minute (min 1 / 2 / 3) | total lost / enqueued | whole-take deltas (pgsteal_kswapd / pgscan_direct / allocstall_movable / pageoutrun / kswapd_low_wmark_hit_quickly / pgmajfault / pswpin) | G1 IPC and cycles | peak NVMe write latency (ms per write) | CSI-2 VC0 OVLF total / seconds with OVLF > 0 | PSI memory some total delta (us) | drive fill and NVMe temp before / after | valid or void |")
print("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
print("\n".join(L))
